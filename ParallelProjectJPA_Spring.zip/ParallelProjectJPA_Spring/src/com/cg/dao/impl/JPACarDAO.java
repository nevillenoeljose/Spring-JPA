package com.cg.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.dao.CarDAO;
import com.cg.dto.CarDTO;

/**
 * 
 * This is a JPACarDAO class
 * 
 * @see java.lang.Object
 * @author Neville
 * 
 *
 */

@Repository
public class JPACarDAO implements CarDAO {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<CarDTO> findAll() {
		try {
			Query query = entityManager.createQuery("select car from CarDTO car");
			return query.getResultList();
		} finally {
			entityManager.close();
		}
	}

	@Override
	public CarDTO findById(int id) {
		try {
			Query query = 
				entityManager.createQuery("select car from CarDTO car where ID = ?");
			query.setParameter(1, id);
			return (CarDTO) query.getResultList();
		} finally {
			entityManager.close();
		}
	}

	@Override
	public void create(CarDTO car) {
		try {
			System.out.println("Inside create car");
			entityManager.merge(car);
			System.out.println("Car added succesfully!");
			System.out.println(car.getId());
			return;
		} finally {
			entityManager.close();
		}
	}

	@Override
	public void update(CarDTO car) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(String[] ids) {
		// TODO Auto-generated method stub
		
	}

}
