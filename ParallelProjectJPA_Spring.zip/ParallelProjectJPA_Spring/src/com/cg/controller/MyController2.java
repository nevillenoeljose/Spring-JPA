package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dao.CarDAO;
import com.cg.dto.CarDTO;

@Controller
@RequestMapping("/controller2")
public class MyController2 {
	private static final String ACTION_KEY = "action";
	private static final String VIEW_CAR_LIST_ACTION = "viewCarList";
	private static final String ADD_CAR_ACTION = "addCar";
	private static final String SAVE_CAR_ACTION = "saveCar";
	private static final String EDIT_CAR_ACTION = "editCar";
	private static final String DELETE_CAR_ACTION = "deleteCar";
	private static final String ERROR_KEY = "errorMessage";
	@Autowired
	private CarDAO carDAO;
	{
		System.out.println("In controller 2");
	}

	@RequestMapping(method = RequestMethod.GET)
	protected String processViewAddRequest(ModelMap map, @RequestParam(ACTION_KEY) String actionName) {
		if ((VIEW_CAR_LIST_ACTION.equals(actionName))) {

			System.out.println("In carlist");
			List<CarDTO> cars = carDAO.findAll();
			map.addAttribute("carList", cars);
			return "carList2";

		} else if (ADD_CAR_ACTION.equals(actionName)) {
			return "carForm2";

		} else {
			String errorMessage = "[" + actionName + "] is not a valid action.";
			map.addAttribute(ERROR_KEY, errorMessage);
			return null;
		}
	}

	@RequestMapping(method = RequestMethod.GET, params = "id")
	protected String processSearchRequest(ModelMap map, @RequestParam(ACTION_KEY) String actionName,
			@RequestParam("id") int id) {
		if (EDIT_CAR_ACTION.equals(actionName)) {
			System.out.println("AA raha hai");
			CarDTO car = carDAO.findById(id);
			map.addAttribute("car", car);
			return "carForm2";

		} else {
			String errorMessage = "[" + actionName + "] is not a valid action.";
			map.addAttribute(ERROR_KEY, errorMessage);
			return null;
		}
	}

	@RequestMapping(method = RequestMethod.POST, params = { "id" })
	protected String processDeleteRequest(ModelMap map, @RequestParam(ACTION_KEY) String actionName,
			@RequestParam(value = "id", required = false) String[] ids, @ModelAttribute("car") CarDTO carDTO) {

		if (SAVE_CAR_ACTION.equals(actionName)) {

			if (carDTO.getId() == -1) {
				carDTO.setId(0);
				carDAO.create(carDTO);
			}
			else
				carDAO.update(carDTO);
			List<CarDTO> cars = carDAO.findAll();
			map.addAttribute("carList", cars);
			return "carList2";

		} else if (DELETE_CAR_ACTION.equals(actionName)) {
			System.out.println("in delete");
			carDAO.delete(ids);
			List<CarDTO> cars = carDAO.findAll();
			map.addAttribute("carList", cars);
			return "carList2";

		} else {
			String errorMessage = "[" + actionName + "] is not a valid action.";
			map.addAttribute(ERROR_KEY, errorMessage);
			return null;
		}

	}

	@ModelAttribute("car")
	protected CarDTO makeCar() {
		CarDTO carDTO = new CarDTO();
		return carDTO;

	}
}