package com.cg.pp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.CarDTO;
import com.cg.pp.beans.Customer;
import com.cg.pp.beans.History;
import com.cg.pp.dao.*;

@Controller
@RequestMapping("/controller")
public class WalletController {
	private static final String ACTION_KEY = "action";
	private static final String VIEW_CUST_ACTION = "viewCust";
	private static final String ADD_CUST_ACTION = "addCust";
	private static final String EDIT_CUST_ACTION = "editCust";
	private static final String DELETE_CUST_ACTION = "deleteCust";
	private static final String SAVE_CUST_ACTION = "saveCust";
	private static final String DEPOSIT_ACTION = "depositCust";
	private static final String WITHDRAW_ACTION = "withdrawCust";
	private static final String TRANSFER_ACTION = "transferCust";
	private static final String HISTORY_ACTION = "historyCust";
	private static final String ERROR_KEY = "errorMessage";

	@Autowired
	private WalletDao walletDAO;
	
	@RequestMapping(method = RequestMethod.GET)
	protected String processViewAddRequest(ModelMap map, @RequestParam(ACTION_KEY) String actionName) {
		if ((VIEW_CUST_ACTION.equals(actionName))) {

			System.out.println("In customer list");
			List<Customer> customers = walletDAO.findAll();
			map.addAttribute("customerList", customers);
			return "customerList";

		} else if (ADD_CUST_ACTION.equals(actionName)) {
			return "customerForm";

		} else {
			String errorMessage = "[" + actionName + "] is not a valid action.";
			map.addAttribute(ERROR_KEY, errorMessage);
			return null;
		}
	}
	
	@RequestMapping(method = RequestMethod.GET, params = "id")
	protected String processSearchRequest(ModelMap map, @RequestParam(ACTION_KEY) String actionName,
			@RequestParam("id") int id) {
		if (EDIT_CUST_ACTION.equals(actionName)) {
			System.out.println("Edit existing customer");
			String mobileno = walletDAO.findById(id).getMobileNo();
			Customer customer = walletDAO.findAccount(mobileno);
			map.addAttribute("customer", customer);
			return "customerForm";

		} else {
			String errorMessage = "[" + actionName + "] is not a valid action.";
			map.addAttribute(ERROR_KEY, errorMessage);
			return null;
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, params = { "id" })
	protected String processDeleteRequest(ModelMap map, @RequestParam(ACTION_KEY) String actionName,
			@RequestParam(value = "id", required = false) String[] ids, @ModelAttribute("customer") Customer customer) {

		if (SAVE_CUST_ACTION.equals(actionName)) {

			if (customer.getId() == -1) {
				customer.setId(0);
				walletDAO.createAccount(customer);
			}
			else
				walletDAO.updateAccount(customer);
			List<Customer> customers = walletDAO.findAll();
			map.addAttribute("customerList", customers);
			return "customerList";

		} else if (DELETE_CUST_ACTION.equals(actionName)) {
			System.out.println("in delete");
			walletDAO.deleteAccounts(ids);
			List<Customer> customers = walletDAO.findAll();
			map.addAttribute("customerList", customers);
			return "customerList";

		} else {
			String errorMessage = "[" + actionName + "] is not a valid action.";
			map.addAttribute(ERROR_KEY, errorMessage);
			return null;
		}

	}
}
