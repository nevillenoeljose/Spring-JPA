package com.cg.pp.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;

@Entity
@Table(name = "Customer")
public class Customer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name="ID")
	private int id;
	
	@Column(name="mobileNo")
	private String mobileNo;
	
	@Column(name="name")
	private String name;
	
	@Column(name="balance")
	private float balance;
	
	// Default constructor
	public Customer() {
        id=-1;
		mobileNo=name="";
		balance=0;
	}
	
	// Parameterized Constructor
	public Customer(String name, String mobileNo, float balance) {
		this.name = name;
		this.mobileNo = mobileNo;
		this.balance = balance;
	}
	
	// Getters and Setters 
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	
	// To String method for Customer object
	@Override
	public String toString() {
		return "\n" + "Customer name=" + name + ", Mobile Num=" + mobileNo
				 + ", Balance= " + balance ;
	}
	
}
